using Sample.Interfaces.ErrorLogging;

namespace Sample.ErrorLogging;

public class ErrorLogger : IErrorLogger
{
    public ErrorLogger()
    {
    }
}
